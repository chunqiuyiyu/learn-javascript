import React, { Component } from 'react';
import './Gallery.less';

class Gallery extends Component {
	constructor () {
		super();
		this.state = {
			gallery: {
				glory: {
					msg: '企鹅电竞杯竞技大礼',
					title: '王者荣耀'
				},
				ninjia: {
					msg: '连续签到领取888金币',
					title: '火影忍者'
				}
			}
		}
	}


	render () {
		return (
			<ul className="gallery">
				{
					Object.keys(this.state.gallery).map(item => (
						<li>
							<img src={`${process.env.PUBLIC_URL}/assets/${item}.png`} />
							<p className="msg">{this.state.gallery[item].msg}</p>
							<p className="title">{this.state.gallery[item].title}</p>
						</li>
					))
				}
			</ul>
		);
	}
}

export default Gallery;
