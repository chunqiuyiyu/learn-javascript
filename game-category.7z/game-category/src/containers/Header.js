import React, { Component } from 'react';
import './Header.less';

class Header extends Component {
	constructor () {
		super();
		this.state = {
			nav: {
				rpg: '角色',
				leisure: '休闲',
				single: '单机',
				card: '棋牌',
				act: '动作',
				fps: '射击'
			}
		}
	}


	render () {
		return (
			<nav>
				<ul className="header">
					{
						Object.keys(this.state.nav).map(item => (
							<li>
								<img src={`${process.env.PUBLIC_URL}/assets/${item}.png`} />
								<div>{this.state.nav[item]}</div>
							</li>
						))
					}
				</ul>
			</nav>
		);
	}
}

export default Header;
