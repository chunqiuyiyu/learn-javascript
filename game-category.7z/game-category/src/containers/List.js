import React, { Component } from 'react';
import './List.less';

class List extends Component {
	constructor () {
		super();
		this.state = {
			data: {
				valley: {
					name: '纪念碑谷',
					desc: '艺术品级的解密游戏',
				},
				bubble: {
					name: '头脑特工队：泡泡乐',
					desc: '迪士尼满分泡泡龙',
				},
				rush: {
					name: '城堡突袭2',
					desc: '年度塔防 不得不玩',
				},
				swallow: {
					name: '无尽吞噬',
					desc: '优雅的吃掉你',
				},
				dots: {
					name: 'TwoDots:冒险之旅',
					desc: '玩的完全停不下来'
				}
			}
		}
	}


	render () {
		return (
			<ul className="games">
				{
					Object.keys(this.state.data).map(item => (
						<li>
							<img src={`${process.env.PUBLIC_URL}/assets/${item}.png`} />
							<div className="border">
								<div className="detail">
									<p className="name">{this.state.data[item].name}</p>
									<p className="desc">{this.state.data[item].desc}</p>
								</div>
								<div className="download">下载</div>
							</div>
						</li>
					))
				}
			</ul>
		);
	}
}

export default List;
